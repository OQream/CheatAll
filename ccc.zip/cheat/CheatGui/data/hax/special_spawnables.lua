-- special spawnable items that don't get found by `gen_spawnlist.py`
special_spawnables = {
  {path='data/entities/animals/boss_alchemist/key.xml', name='Crystal Key', xml="key.xml"},
  {path='data/entities/animals/boss_centipede/sampo.xml', name='Sampo', xml="sampo.xml"},
}